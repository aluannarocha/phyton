#run.py

from app.app import app
from app.views import *

if __name__ == '__main__':
    app.run(debug=True)